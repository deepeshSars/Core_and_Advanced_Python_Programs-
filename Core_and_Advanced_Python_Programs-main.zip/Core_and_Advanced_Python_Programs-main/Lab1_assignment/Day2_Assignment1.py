Python 3.12.1 (tags/v3.12.1:2305ca5, Dec  7 2023, 22:03:25) [MSC v.1937 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> # Take input from the user
... num1 = float(input("Enter first number: "))
Enter first number: 3
>>> num2 = float(input("Enter second number: "))
... 
Enter second number: 5
>>> # Calculate sum and multiplication
... sum_result = num1 + num2
>>> multiplication_result = num1 * num2
>>> # Display the results
... print(f"Sum: {sum_result}")
Sum: 8.0
>>> print(f"Multiplication: {multiplication_result}")
Multiplication: 15.0
