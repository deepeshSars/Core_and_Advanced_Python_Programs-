def square(num):
    return num ** 2

# Calling the function
number = 5
result = square(number)

print(f"The square of {number} is: {result}")


#OUTPUT
"""
The square of 5 is: 25
"""