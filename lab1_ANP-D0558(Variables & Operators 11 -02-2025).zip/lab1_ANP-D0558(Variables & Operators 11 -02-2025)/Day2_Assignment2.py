Python 3.12.1 (tags/v3.12.1:2305ca5, Dec  7 2023, 22:03:25) [MSC v.1937 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> # Declare two variables
... a = 10
>>> b = 20
>>> # Find the largest using a ternary operator
... largest = a if a > b else b
>>> # Print the largest variable
... print(f"The largest number is: {largest}")
The largest number is: 20
